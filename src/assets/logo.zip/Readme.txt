Logo designed using Online Logo Maker
https://onlinelogomaker.com

Fonts used in this project:

https://assets.onlinelogomaker.com/fonts/Masque.ttf
https://assets.onlinelogomaker.com/fonts/Masque.ttf


Instructions to install fonts on windows: 
 1- Find and Download your fonts from the links above 
 2- Double click the .ttf file 
 3- Click on the install button and allow it to install